"use strict";

const createStopwatch = (minuteSpan, secondSpan, msSpan) => {
    // private state
    
    
    // public methods
    
};